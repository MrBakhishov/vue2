<template>
  <div >

<button  @click="yenioyun">oyuna bashla</button>
<h2 > user: {{dovshan}}</h2>
<h1>canavar : {{monsterHeal}} </h1>
<p> cem : {{data}}</p>
<button @click="hucum" type="button" class="btn btn-primary mb-3">hucum</button>
<button @click="siddethucum" type="button" class="btn btn-secondary">siddethucum</button>
<button @click="xaltop" type="button" class="btn btn-success">xal topla</button>
<button type="button" class="btn btn-danger">Danger</button>
<button type="button" class="btn btn-warning">Warning</button>


  </div>
</template>


<script>
export default {
data(){
return{

monsterHeal: 100,
dovshan: 100,
gameOn: false,
turnArray: []
};

},


methods: {

  hucum(){
 this.monsterHeal -= Math.round(Math.random()*5);
 this.dovshan -= Math.round(Math.random()*5);
  },
  siddethucum(){
    this.monsterHeal -= Math.round(Math.random()*5);
    this.dovshan -= Math.round(Math.random()*10)

  }
}
// yenioyun(){
//       this.gameOn = true;
//       this.monsterHeal = 100;
//       this.dovshan = 100;
//       this.turnArray = [];

// },

// uddun () {
//       if (this.monsterHeal <= 0) {
//         if (confirm("YOU WIN! Do you want to play again?")) {
//           this.newGame();
//         } else {
//           this.newGame = false;
//         }
//         return true;
//       } else if (this.dovshan <= 0) {
//         if (confirm("YOU LOSE!Wanna try again ? ")) {
//           this.newGame();
//         } else {
//           this.newGame = false;
//         }
//         return true;
//       }
//       return false;
   // },


}

</script>